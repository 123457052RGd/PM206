from fastapi import FastAPI  # type: ignore
# pyright: ignore[reportMissingImports]
# pyright: ignore[reportMissingImports]

from fastapi.middleware.cors import CORSMiddleware
from app.routers import usuarios
from app.data.db import engine
from app.data import usuarioDB

# Crear las tablas
usuarioDB.Base.metadata.create_all(bind=engine)

# Crear la aplicación
app = FastAPI(
    title="API usuarios",
    description="Diego Rubio Guerrero",
    version="1.0.0"
)

# Agregar middleware (Corregido para permitir todo)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Registrar rutas
app.include_router(usuarios.router)
